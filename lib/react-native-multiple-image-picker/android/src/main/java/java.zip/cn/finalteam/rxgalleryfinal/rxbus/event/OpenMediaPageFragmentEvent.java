package cn.finalteam.rxgalleryfinal.rxbus.event;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/7/27 下午2:15
 */
public class OpenMediaPageFragmentEvent {
}

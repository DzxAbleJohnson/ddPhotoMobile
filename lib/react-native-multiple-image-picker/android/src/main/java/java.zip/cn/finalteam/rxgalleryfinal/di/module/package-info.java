/**
 * Dagger2 module
 */
package cn.finalteam.rxgalleryfinal.di.module;
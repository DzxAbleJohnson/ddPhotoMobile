package cn.finalteam.rxgalleryfinal.presenter.impl;

import cn.finalteam.rxgalleryfinal.presenter.ActivityFragmentPresenter;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/5/14 下午11:16
 */
public class ActivityFragmentPresenterImpl implements ActivityFragmentPresenter {
}

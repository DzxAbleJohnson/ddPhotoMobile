/**
 * rxjava实现事件总线
 */
package cn.finalteam.rxgalleryfinal.rxbus;
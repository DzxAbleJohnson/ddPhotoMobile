package cn.finalteam.rxgalleryfinal.imageloader;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/7/25 下午3:36
 */
public enum ImageLoaderType {
    PICASSO
}

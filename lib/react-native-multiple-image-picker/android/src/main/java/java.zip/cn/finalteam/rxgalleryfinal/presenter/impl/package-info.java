/**
 * MVP P层包(调度)--实现
 */
package cn.finalteam.rxgalleryfinal.presenter.impl;
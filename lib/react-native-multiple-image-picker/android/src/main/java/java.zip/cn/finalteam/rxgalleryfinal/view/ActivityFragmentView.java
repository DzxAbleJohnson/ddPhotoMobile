package cn.finalteam.rxgalleryfinal.view;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/5/14 下午9:56
 */
public interface ActivityFragmentView {

    void showMediaGridFragment();
    void showMediaPageFragment();
    void showMediaPreviewFragment();
}

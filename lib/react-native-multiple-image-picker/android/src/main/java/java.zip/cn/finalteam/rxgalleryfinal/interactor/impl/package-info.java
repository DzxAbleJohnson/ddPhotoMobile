/**
 * MVP M层包(业务生产)--实现
 */
package cn.finalteam.rxgalleryfinal.interactor.impl;
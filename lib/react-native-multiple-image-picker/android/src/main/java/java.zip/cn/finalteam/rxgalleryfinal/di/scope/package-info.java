/**
 * Dagger2 scope
 */
package cn.finalteam.rxgalleryfinal.di.scope;
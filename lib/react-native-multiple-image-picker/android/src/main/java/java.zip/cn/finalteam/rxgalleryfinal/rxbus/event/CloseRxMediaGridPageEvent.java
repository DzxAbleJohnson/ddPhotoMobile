package cn.finalteam.rxgalleryfinal.rxbus.event;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/8/1 下午11:51
 */
public class CloseRxMediaGridPageEvent {
}

/**
 * MVP V接口
 */
package cn.finalteam.rxgalleryfinal.view;
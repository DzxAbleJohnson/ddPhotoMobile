/**
 * 事件包
 */
package cn.finalteam.rxgalleryfinal.rxbus.event;
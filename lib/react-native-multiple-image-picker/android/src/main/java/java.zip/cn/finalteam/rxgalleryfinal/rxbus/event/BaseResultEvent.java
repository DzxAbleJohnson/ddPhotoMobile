package cn.finalteam.rxgalleryfinal.rxbus.event;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/7/31 下午10:37
 */
public interface BaseResultEvent {
}

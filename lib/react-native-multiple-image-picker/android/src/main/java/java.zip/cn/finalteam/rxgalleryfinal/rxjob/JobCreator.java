package cn.finalteam.rxgalleryfinal.rxjob;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/7/31 上午9:10
 */
public interface JobCreator {
    Job create();
}

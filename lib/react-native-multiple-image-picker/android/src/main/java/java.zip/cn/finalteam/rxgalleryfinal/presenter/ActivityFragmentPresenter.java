package cn.finalteam.rxgalleryfinal.presenter;

/**
 * Desction:activity fragment presenter
 * Author:pengjianbo
 * Date:16/5/14 下午11:12
 */
public interface ActivityFragmentPresenter {
}

package cn.finalteam.rxgalleryfinal.rxbus.event;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/7/28 上午12:19
 */
public class CloseMediaViewPageFragmentEvent {
}

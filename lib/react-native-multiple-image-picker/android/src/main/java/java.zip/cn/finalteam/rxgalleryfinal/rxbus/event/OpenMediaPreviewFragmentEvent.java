package cn.finalteam.rxgalleryfinal.rxbus.event;

/**
 * Desction:
 * Author:pengjianbo
 * Date:16/7/23 下午3:49
 */
public class OpenMediaPreviewFragmentEvent {
}

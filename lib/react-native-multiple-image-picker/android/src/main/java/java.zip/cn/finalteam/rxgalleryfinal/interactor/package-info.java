/**
 * MVP M层包(业务生产)--抽象
 */
package cn.finalteam.rxgalleryfinal.interactor;
/**
 * 数据模型
 */
package cn.finalteam.rxgalleryfinal.bean;
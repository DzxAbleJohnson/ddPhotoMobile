/**
 * MVP P层包(调度)--抽象
 */
package cn.finalteam.rxgalleryfinal.presenter;
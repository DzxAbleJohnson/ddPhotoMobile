/**
 * Dagger2 component
 */
package cn.finalteam.rxgalleryfinal.di.component;